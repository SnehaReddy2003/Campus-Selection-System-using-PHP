<?php 
include '../db.php'; 
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if form is submitted
if (isset($_POST['submit'])) {

    // Trim and sanitize inputs
    $name = trim($_POST['name']);
    $password = trim($_POST['password']);
    $email = trim($_POST['email']);
    $sapid = trim($_POST['sapid']);
    $contact = trim($_POST['contact']);
    $dept = trim($_POST['dept']);
    $cgpa = trim($_POST['cgpa']);

    // Debugging: Check if values are received correctly
    echo "<script>console.log('Received Input Data: " . json_encode($_POST) . "');</script>";

    // Error array
    $error = [];

    // Validation checks
    if (empty($name)) $error['name'] = "Name is required!";
    if (empty($password) || strlen($password) < 6) $error['password'] = "Password must be at least 6 characters!";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $error['email'] = "Valid email is required!";
    if (empty($sapid) || !ctype_digit($sapid)) $error['sapid'] = "Valid SAP ID is required!";
    if (empty($contact) || !ctype_digit($contact) || strlen($contact) != 10) $error['contact'] = "Valid 10-digit contact number required!";
    if (empty($dept)) $error['dept'] = "Department is required!";
    if (empty($cgpa) || !is_numeric($cgpa) || $cgpa < 0 || $cgpa > 10) $error['cgpa'] = "Valid CGPA (0-10) required!";

    // If errors exist, show message and stop execution
    if (!empty($error)) {
        echo "<script>alert('Please fix the errors and try again!');</script>";
        exit();
    }

    // Check database connection
    if (!$connection) {
        die("Database connection failed: " . mysqli_connect_error());
    } else {
        echo "<script>console.log('Database connected successfully');</script>";
    }

    // Check if SAP ID already exists
    $cquery = "SELECT * FROM student WHERE sapid = ?";
    $stmt = mysqli_prepare($connection, $cquery);
    mysqli_stmt_bind_param($stmt, "s", $sapid);
    mysqli_stmt_execute($stmt);
    $cresult = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($cresult) > 0) {
        echo "<script>alert('SAP ID already registered!');</script>";
    } else {
        // Secure password hashing
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);

        // Insert data securely
        $query = "INSERT INTO student (name, email, contact, password, cgpa, sapid, dept) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($connection, $query);

        if (!$stmt) {
            die("SQL Preparation Failed: " . mysqli_error($connection));
        }

        mysqli_stmt_bind_param($stmt, "sssssss", $name, $email, $contact, $hashed_password, $cgpa, $sapid, $dept);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            echo "<script>alert('Registration Successful! Redirecting to Login Page...');</script>";
            echo "<script>window.location.href='login.php';</script>";
            exit();
        } else {
            die("Error in Registration: " . mysqli_error($connection));
        }
    }
    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Register</title>
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">
</head>
<body class="light-gray-bg">

    <div class="templatemo-content-widget templatemo-login-widget white-bg">
        <header class="text-center">
            <div class="square"></div>
            <h1>Student Register</h1>
        </header>
        <form method="POST" class="templatemo-login-form" action="register.php">
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-user fa-fw"></i></div>
                    <input type="text" name="name" class="form-control" placeholder="Name" required>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon">@</div>
                    <input type="email" name="email" class="form-control" placeholder="Email" required>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon">#</div>
                    <input type="text" name="sapid" class="form-control" placeholder="SAP ID" required>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon">%</div>
                    <input type="text" name="cgpa" class="form-control" placeholder="CGPA" required>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-phone fa-fw"></i></div>
                    <input type="text" name="contact" class="form-control" placeholder="Contact (10-digit)" required>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-key fa-fw"></i></div>
                    <input type="password" name="password" class="form-control" placeholder="Password (Min 6 characters)" required>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label templatemo-block">Department</label>
                <select class="form-control" name="dept" required>
                    <option value="Computer">Computer</option>
                    <option value="IT">IT</option>
                    <option value="Mechanical">Mechanical</option>
                    <option value="EXTC">EXTC</option>
                    <option value="Chemical">Chemical</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" name="submit" class="templatemo-blue-button width-100">Register</button>
            </div>
        </form>
    </div>

    <div class="templatemo-content-widget templatemo-login-widget templatemo-register-widget white-bg">
        <p>Have an Account? <strong><a href="login.php" class="blue-text">Sign in here!</a></strong></p>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>
