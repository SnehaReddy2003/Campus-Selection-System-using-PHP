<div class="footer">
  <div class="container">
    <div class="col-md-3 ftr_navi ftr">
      <h3>NAVIGATION</h3>
      <ul>
        <li>
          <a href="../index.php">Home</a>
        </li>
        <li>
          <a href="./login.php">Student Login</a>
        </li>
        <li>
          <a href="../companies/login.php">Company Login</a>
        </li>

        <li>
          <a href="../admin/login.php">Admin Login</a>
        </li>
      </ul>
    </div>
    <!-- <div class="col-md-3 ftr_navi ftr">
      <h3>MEMBERS</h3>
      <ul>
        <li>
          <a href="#">Customer Support</a>
        </li>
        <li>
          <a href="#">Placement Support</a>
        </li>
        <li>
          <a href="#">Faculty Support</a>
        </li>
        <li>
          <a href="#">Registered Companies</a>
        </li>
        <li>
          <a href="#">Training</a>
        </li>
      </ul>
    </div> -->
    <div class="col-md-3 get_in_touch ftr">
      <h3>GET IN TOUCH</h3>
      <p>Plot No.18</p>
      <p>JVPD Scheme,Vile Parle(West)</p>
      <p>08138-229918/223775</p>
      <a href="mailto:djsce@gmail.com">djsce@gmail.com</a>
    </div>
    <div class="col-md-3 get_in_touch ftr">

    </div>
    <div class="col-md-3 ftr-logo">
      <p>Copyright &copy; DJSCE-2018

    </div>
    </div>

  </div>
