# Placement-Management-System

## Problem Definition:
An application that provides information related to the Placement Management system and smoothens the process by automation and using a well designed Database System. 

### Features:
* Information regarding every student in the college
* Individual attributes of student and company
* Details of all the applied students 
* Details of the admins (faculty members)

The database will store record of each student, company, applied students and admins using a MYSQL database.

### Functional requirements:

A step by step series of examples that tell you how to get a development env running




Here are some screenshorts of the project.
![screenshot](https://user-images.githubusercontent.com/35973080/47303062-a3d9a180-d640-11e8-9cd0-c0427aa246ad.png)

![p_chart](https://user-images.githubusercontent.com/35973080/47303113-b6ec7180-d640-11e8-87ed-cb5df3aea960.png)

![p1](https://user-images.githubusercontent.com/35973080/47303145-c9ff4180-d640-11e8-8af0-62fa32fff798.png)

![pstudentt](https://user-images.githubusercontent.com/35973080/47303173-db484e00-d640-11e8-8e6b-721a69128e60.png)
